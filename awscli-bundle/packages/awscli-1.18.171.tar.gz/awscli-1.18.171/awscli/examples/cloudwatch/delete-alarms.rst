**To delete an alarm**

The following example uses the ``delete-alarms`` command to delete the Amazon CloudWatch alarm
named "myalarm"::

  aws cloudwatch delete-alarms --alarm-names myalarm

Output::

  This command returns to the prompt if successful.
